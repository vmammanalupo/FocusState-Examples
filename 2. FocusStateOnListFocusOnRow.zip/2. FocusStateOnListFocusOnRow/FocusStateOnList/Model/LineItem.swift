//
//  LineItem.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import Foundation

struct LineItem: Codable, Hashable, Identifiable {
    let product: Product
    var productQuantity: Int

    var id: UUID {
        product.id
    }
}
