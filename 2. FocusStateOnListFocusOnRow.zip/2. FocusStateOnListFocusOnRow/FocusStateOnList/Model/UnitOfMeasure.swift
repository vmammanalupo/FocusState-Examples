//
//  UnitOfMeasure.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import Foundation

enum UOM: String, Codable {
    case each = "EACH"
    case pair = "PAIR"
    case pack = "PACK"
}

struct UnitOfMeasure: Codable, Hashable {
    let type: UOM
    let quantity: Int

    func quantity(forBaseUnitQuantity baseUnitQuantity: Int) -> Int {
        return baseUnitQuantity / quantity
    }

    var displayName: LocalizedStringResource {
        switch type {
        case .each:
            return "each"
        case .pair:
            return "pairs"
        case .pack:
            return "pkg. of \(quantity)"
        }
    }
}
