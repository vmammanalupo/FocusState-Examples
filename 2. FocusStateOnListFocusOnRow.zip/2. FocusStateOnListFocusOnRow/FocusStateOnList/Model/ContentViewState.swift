//
//  ContentViewState.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import Foundation

struct ContentViewState {
    var lineItems: [LineItem]
}
