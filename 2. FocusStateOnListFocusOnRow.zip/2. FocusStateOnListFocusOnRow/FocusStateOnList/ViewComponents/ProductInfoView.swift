//
//  ProductInfoView.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import SwiftUI

struct ProductInfoView: View {
    // MARK: - Private Properties

    private let partNumber: String
    private let description: String
    private let brand: String?

    // MARK: - Life Cycle

    init(partNumber: String, description: String, brand: String? = nil) {
        self.partNumber = partNumber
        self.description = description
        self.brand = brand
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4.0) {
            if let brand, !brand.isEmpty {
                Text(brand)
                    .font(.caption)
            }
            Text(partNumber)
                .font(.subheadline)
                .fontWeight(.semibold)
            Text(description)
                .font(.footnote)
                .fontWeight(.medium)
        }
        .padding(.trailing, 8)
        .fixedSize(horizontal: false, vertical: true)
    }
}
