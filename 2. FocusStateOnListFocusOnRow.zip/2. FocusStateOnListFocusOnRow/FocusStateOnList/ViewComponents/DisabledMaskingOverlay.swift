//
//  DisabledMaskingOverlay.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import SwiftUI

extension View {
    func maskingOverlay<T: Hashable>(focusId: Binding<T?>, elementId: T?) -> some View {
        modifier(DisabledMaskingOverlay(focusId: focusId, elementId: elementId))
    }
}

struct DisabledMaskingOverlay<T: Hashable>: ViewModifier {
    @Binding var focusId: T?
    let elementId: T?

    func body(content: Content) -> some View {
        content
            .disabled(shouldDisable)
            .overlay {
                if shouldDisable {
                    Color.secondary.opacity(0.2)
                }
            }
    }

    private var shouldDisable: Bool {
        guard let focusId, let elementId else { return false }
        return focusId != elementId
    }
}
