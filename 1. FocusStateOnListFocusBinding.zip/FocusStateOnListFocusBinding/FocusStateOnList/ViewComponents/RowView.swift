//
//  RowView.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import SwiftUI

struct RowView: View {

    // MARK: - Constants

    private enum Constants {
        static let dropDownImageName = "chevron.down"
    }

    // MARK: - Private Properties

    @Environment(\.dismissSearch) private var dismissSearch
    @FocusState.Binding private var focus: String?
    @Binding private var focusedLineItemId: String?
    @Binding private var lineItem: LineItem
    @State private var textFieldValue: String
    @State private var isError: Bool = false

    // MARK: - Life Cycle

    init(
        lineItem: Binding<LineItem>,
        focusedLineItemId: Binding<String?>,
        focus: FocusState<String?>.Binding
    ) {
        self._lineItem = lineItem
        self._textFieldValue = State(initialValue: String(lineItem.wrappedValue.productQuantity))
        self._focusedLineItemId = focusedLineItemId
        self._focus = focus
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                ProductImage()
                    .frame(width: 74, height: 74)
                VStack(alignment: .leading) {
                    ProductInfoView(
                        partNumber: product.partNumber,
                        description: product.description,
                        brand: product.brand
                    )
                    
                    quantityView

                    if lineItem.product.minimumShipPackQuantity > 1 {
                        Text("This product can only be shipped in multiples of \(lineItem.product.minimumShipPackQuantity).")
                            .font(.caption2)
                            .foregroundStyle(isError ? Color.red : Color.secondary)
                            .padding(.top, 4)
                    }
                }
            }
            actionToolbar
        }
        .padding(16)
        .onAppear {
            textFieldValue = "\(lineItem.productQuantity)"
        }
        .buttonStyle(.plain)
    }

    // MARK: - Private Computed Properties

    private var product: Product {
        lineItem.product
    }

    private var focusId: String {
        lineItem.id.uuidString
    }

    @ViewBuilder
    private var actionToolbar: some View {
        HStack(spacing: 32) {
            Spacer()
            if focusedLineItemId == focusId {
                cancelButton
                doneButton
            } else {
                addButton
            }
        }
    }

    private var cancelButton: some View {
        Button("Cancel") {
            textFieldValue = "\(lineItem.productQuantity)"
            validate(lineItem.productQuantity)
            focusedLineItemId = nil
        }
    }

    private var doneButton: some View {
        /* 
         We are seeing a warning regarding MainActor here.
         I want this code to be executed on the main thread.
         Is this not the way to go?
         */
        Button("Done") { @MainActor in
            validate(lineItem.productQuantity)
            focusedLineItemId = nil
            saveQuantity()
        }
        .disabled(isError || textFieldValueAsInt == 0)
    }

    private var addButton: some View {
        Button("Add") {}
    }

    private var quantityView: some View {
        ZStack(alignment: .leading) {
            //  We make sure the TextField is always ready to be focused on by hiding it with opacity.
            focusedQuantityView
                .opacity(focusedLineItemId == focusId ? 1.0 : 0.0)
            unfocusedQuantityView
                .opacity(focusedLineItemId != focusId ? 1.0 : 0.0)
        }
        .onChange(of: textFieldValue) {
            validate(textFieldValueAsInt)
            textFieldValue = "\(textFieldValueAsInt)"
        }
    }

    private var focusedQuantityView: some View {
        VStack(alignment: .leading) {
            Text("Qty")
                .font(.caption)
                .foregroundStyle(.primary)
                .padding(.leading, 15)

            HStack {
                TextField("", text: $textFieldValue)
                    .focused($focus, equals: focusId)
                    .fixedSize(horizontal: true, vertical: false)
                    .frame(width: focusedLineItemId == focusId ? 49 : 0, height: focusedLineItemId == focusId ? 44 : 0)
                    .multilineTextAlignment(.center)
                    .keyboardType(.numberPad)
                    .overlay {
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(.tertiary, lineWidth: 1)
                    }
                /* 
                 We use this modifier to select all the contents of the TextField once we first focus.
                 Is there another way to achieve this with SwiftUI directly?
                 */
                    .onReceive(
                        NotificationCenter.default.publisher(for: UITextField.textDidBeginEditingNotification)
                    ) { obj in
                        if let textField = obj.object as? UITextField {
                            textField.selectedTextRange = textField.textRange(
                                from: textField.beginningOfDocument,
                                to: textField.endOfDocument
                            )
                        }
                    }

                Text(lineItem.product.uom.displayName)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var unfocusedQuantityView: some View {
        HStack(spacing: 16) {
            Button {
                focusedLineItemId = focusId
            } label: {
                HStack(spacing: 8.0) {
                    Text("Qty: ")
                        .font(.footnote)
                    Text(verbatim: "\(lineItem.productQuantity)")
                        .font(.callout)
                        .fontWeight(.semibold)
                    Image(systemName: Constants.dropDownImageName)
                        .resizable()
                        .frame(width: 9.0, height: 4.0)
                }
            }
            Text(lineItem.product.uom.displayName)
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer()
        }
    }

    private var textFieldValueAsInt: Int {
        Int(String(textFieldValue.prefix(4))) ?? 0
    }

    private func validate(_ newValue: Int) {
        let minimumShipPackQuantity = lineItem.product.minimumShipPackQuantity
        isError = !newValue.isMultiple(of: minimumShipPackQuantity)
    }

    @MainActor
    private func saveQuantity() {
        validate(textFieldValueAsInt)
        textFieldValue = "\(textFieldValueAsInt)"
        lineItem.productQuantity = textFieldValueAsInt
    }
}
