//
//  ProductImage.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import SwiftUI

struct ProductImage: View {

    // MARK: - Life Cycle

    var body: some View {
        Image(systemName: "photo")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .foregroundStyle(.gray)
    }
}

#Preview {
    ProductImage()
}
