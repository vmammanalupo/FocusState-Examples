//
//  ContentView.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import SwiftUI

struct ContentView: View {

    // MARK: - Constant

    enum Constant {
        static let logTag = "AddReplenishmentProductView"
    }

    @Binding var state: ContentViewState

    // MARK: - Private Properties

    @State private var focusedLineItemId: String?
    @FocusState private var focus: String?

    // MARK: - Life cycle

    var body: some View {
        VStack {
            replenishmentProductList
        }
        .background(.tertiary)
        .navigationTitle("Add Products")
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.visible, for: .navigationBar)
    }

    // MARK: - Private Computed properties

    @ViewBuilder
    private var replenishmentProductList: some View {
        ScrollViewReader { proxy in
            List {
                let list = Array(state.lineItems.enumerated())
                ForEach(list, id: \.1.product.id) { (index, lineItem) in
                    RowView(
                        lineItem: $state.lineItems[index],
                        focusedLineItemId: $focusedLineItemId,
                        focus: $focus
                    )
                    .id(lineItem.id.uuidString)
                    .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                    .alignmentGuide(.listRowSeparatorLeading) { _ in
                        return 0
                    }
                    //  Blocks all the other rows that we are not focusing on.
                    .maskingOverlay(focusId: $focusedLineItemId, elementId: "\(lineItem.id)")
                }
                .listSectionSeparator(.hidden)
            }
            .listStyle(.plain)
            .scrollDismissesKeyboard(.never)
            .scrollContentBackground(.hidden)
            /* 
             We are looking for a solution that doesn't require us to have this onChange modifier
             whenever we want to change a focus.
             */
            .onChange(of: focusedLineItemId) {
                /* 
                 We need to scroll to a whole RowView so we can see both done and cancel buttons.
                 Without this, the focus will auto-scroll only to the text field, due to updating FocusState.

                 However, we are experiencing weird jumping issues. It feels like the animations for focus on
                 text field and RowView are clashing between each other.
                 */
                focus = focusedLineItemId
                guard let lineItemId = focusedLineItemId else { return }
                withAnimation {
                    //  We need to add the withAnimation call to animate the scroll to the whole row.
                    proxy.scrollTo(lineItemId, anchor: .top)
                }
            }
        }
    }
}
