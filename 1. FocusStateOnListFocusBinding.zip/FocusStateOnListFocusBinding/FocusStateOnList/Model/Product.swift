//
//  Product.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import Foundation

struct Product: Hashable, Identifiable, Codable {
    let id: UUID
    let description: String
    let brand: String?
    let partNumber: String
    let uom: UnitOfMeasure
    let minimumShipPackQuantity: Int

    func containsText(_ searchText: String) -> Bool {
        let searchText = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !searchText.isEmpty else { return true }
        return partNumber.lowercased().contains(searchText)
        || description.lowercased().contains(searchText)
    }
}
