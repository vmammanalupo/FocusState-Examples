//
//  FocusStateOnListApp.swift
//  FocusStateOnList
//
//  Created by DelRealEscudero, Francisco on 10/10/24.
//

import SwiftUI

@main
struct FocusStateOnListApp: App {

    @State var state = ContentViewState(
        lineItems: products.map { LineItem(product: $0, productQuantity: $0.minimumShipPackQuantity) }
    )

    var body: some Scene {
        WindowGroup {
            NavigationStack {
                ContentView(state: $state)
            }
        }
    }
}

let products: [Product] = [
    Product(
        id: UUID(),
        description: "Battery: D, Everyday, Alkaline, 1.5V DC, Procell Constant, 12 PK",
        brand: "DURACELL PROCELL",
        partNumber: "5LE21",
        uom: UnitOfMeasure(type: .pack, quantity: 12),
        minimumShipPackQuantity: 1
    ),
    Product(
        id: UUID(),
        description: "Battery: C, Everyday, Alkaline, 1.5V DC, Procell Constant, 12 PK",
        brand: "DURACELL PROCELL",
        partNumber: "5LE22",
        uom: UnitOfMeasure(type: .pack, quantity: 12),
        minimumShipPackQuantity: 1
    ),
    Product(
        id: UUID(),
        description: "Battery: AA, Everyday, Alkaline, 1.5V DC, Procell Constant, 24 PK",
        brand: "DURACELL PROCELL",
        partNumber: "5LE23",
        uom: UnitOfMeasure(type: .pack, quantity: 24),
        minimumShipPackQuantity: 1
    ),
    Product(
        id: UUID(),
        description: "Combination Cartridge/Filter: Magenta/Olive Color, Threaded, 1 PR",
        brand: "HONEYWELL NORTH",
        partNumber: "16M236",
        uom: UnitOfMeasure(type: .pair, quantity: 1),
        minimumShipPackQuantity: 4
    ),
    Product(
        id: UUID(),
        description: "Back Support with Stay: M Back Support Size, 8 in Wd, 30 in to 34 in Fits Waist Size, Elastic",
        brand: "CONDOR",
        partNumber: "1UM60",
        uom: UnitOfMeasure(type: .each, quantity: 1),
        minimumShipPackQuantity: 1
    ),
    Product(
        id: UUID(),
        description: "Hard Hat: White, No Graphics, Polyethylene, Side-Slots, MSA, Basic Colors, V-Gard Large(R)",
        brand: "MSA",
        partNumber: "9FLG7",
        uom: UnitOfMeasure(type: .each, quantity: 1),
        minimumShipPackQuantity: 1
    ),
    Product(
        id: UUID(),
        description: "BIRD-X Coyote, 2-D: Goose, Duck and Rodent Control",
        brand: "BIRD-X",
        partNumber: "8ENF6",
        uom: UnitOfMeasure(type: .each, quantity: 1),
        minimumShipPackQuantity: 1
    )
]
